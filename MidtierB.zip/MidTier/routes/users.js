var express = require('express');
var router = express.Router();
const got = require('got');

/* GET users listing. */
router.get('/', function(req, res, next) {
  got('http://localhost:8080/library/books').then(result => {
    res.send(result.body);
  }).catch(error => {
    console.log('Error: ' + error);
  });
});

module.exports = router;
